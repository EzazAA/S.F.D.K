function navigate(){
    let url = document.querySelector('.navOnPhone select').value;
    window.location.href = url;
}